package element;

public class Receptionner {
	
	private String receptionner;
	/*String receptive or nihiliste*/
	public Receptionner(String receptionner) {
		this.receptionner=receptionner;
	}
	public String getType() {
		return receptionner;
	}
}
