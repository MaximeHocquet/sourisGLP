package element;

import java.util.ArrayList;
import java.util.HashMap;

import configuration.SimulationConfiguration;
import duree.Tours;
/*Memoire d'une souris. Elle est capable de memoriser les tours de son vivant , le tour quand elle est nee
 * le tour quand elle est morte. Elle memorise aussi les sources, souris, ses enfants, et obstacles qu'elle rencontre.*/
public class Memoire {
	
	private Tours tours;
	private Tours naissance;
	private int mortTours;
	
	private Souris mariage;
	private ArrayList<Source> sources;
	private ArrayList<Obstacle> obstacles;
	private ArrayList<Souris> souris;
	private ArrayList<Souris> enfants;
	
	private HashMap<Object, String> memoireParTours= new HashMap<Object, String>();
	
	public Memoire(Tours naissance) {
		
		this.naissance=naissance;
		this.mortTours=SimulationConfiguration.SIMULATION_DURATION;
		
		this.sources=new ArrayList<Source>();
		this.obstacles=new ArrayList<Obstacle>();
		this.souris=new ArrayList<Souris>();
		this.enfants=new ArrayList<Souris>();
	}
	public void memoireParTours(Object tours, String object) {
		 memoireParTours.put(tours, object);
	}

	public Tours getTours() {
		return tours;
	}
	
	public ArrayList<Source> getSources() {
		return sources;
	}
	
	public ArrayList< Obstacle> getObstacles() {
		return obstacles;
	}
	
	public ArrayList<Souris> getSouris() {
		return souris;
	}
	
	public ArrayList<Souris> getEnfants() {
		return enfants;
	}
	
	public void setSources(ArrayList<Source> sources) {
		this.sources = sources;
	}
	
	public void setObstacles(ArrayList<Obstacle> obstacles) {
		this.obstacles = obstacles;
	}
	
	public void setSouris(ArrayList<Souris> souris) {
		this.souris = souris;
	}
	
	public void setEnfants(ArrayList<Souris> enfants) {
		this.enfants = enfants;
	}
	
	public Souris getMariage() {
		return mariage;
	}
	
	public void setMariage(Souris mariage) {
		this.mariage = mariage;
	}
	
	public Tours getNaissance() {
		return naissance;
	}
	
	public int getMortTours() {
		return mortTours;
	}
	
	public void setMortTours(int mortTours) {
		this.mortTours = mortTours;
	}
	
	public HashMap<Object, String> getMemoireParTours() {
		return memoireParTours;
	}
	
	public void setMemoireParTours(HashMap<Object, String> memoireParTours) {
		this.memoireParTours = memoireParTours;
	}
}
