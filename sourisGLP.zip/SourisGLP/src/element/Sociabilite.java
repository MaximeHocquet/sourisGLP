package element;
/*La sociabilite determine si une souris decide de diffuser ou receptionner une information*/
public class Sociabilite{
	
	private int valeurSociabilite;

	public Sociabilite(int valeurSociabilite) {
		this.valeurSociabilite = valeurSociabilite;
	}

	public int getValeurSociabilite() {
		return valeurSociabilite;
	}
	
}
