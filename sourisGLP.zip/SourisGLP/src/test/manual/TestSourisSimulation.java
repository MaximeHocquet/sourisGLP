package test.manual;

import gui.HomeGUI;

public class TestSourisSimulation {
	public static void main(String[] args) {
		new HomeGUI("Mousimulation");
	}
}
