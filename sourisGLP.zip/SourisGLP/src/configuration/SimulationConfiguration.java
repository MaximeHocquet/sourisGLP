package configuration;

public class SimulationConfiguration {
	public static final int WINDOW_WIDTH = 600;
	public static final int WINDOW_HEIGHT = 600;

	public static int BLOCK_SIZE = 20;
	
	public static int LINE_COUNT = WINDOW_WIDTH / BLOCK_SIZE;
	public static int COLUMN_COUNT = WINDOW_HEIGHT / BLOCK_SIZE;
	
	public static final int SIMULATION_SPEED = 1000;
	
	public static int SOURCE_CONTENT=50;
	public static int MAX_SOURIS_NOURRITURE=15;
	public static int START_SOURIS_NOURRITURE=10;
	public static int NEW_SOURIS=13;
	
	public static int GENERATION_COOPERATIVE=50;
	public static int GENERATION_RECEPTIVE=50;
	public static int GENERATION_SEXE=50;
	public static int SEUIL_COOPERATION=50;
	public static int SEUIL_RECEPTION=50;
	
	public static int NUMBER_SOURIS=40;
	public static int NUMBER_OBSTACLE=20;
	public static int NUMBER_SOURCE=20;
	
	public static int SIMULATION_DURATION=100;
	
	public static int STOP=0;
	
	public static int STOP_TOURS=0;
}
