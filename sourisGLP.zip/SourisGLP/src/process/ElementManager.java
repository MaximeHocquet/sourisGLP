package process;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import configuration.SimulationConfiguration;
import duree.Tours;
import element.Communication;
import element.Comportement;
import element.Diffuser;
import element.Memoire;
import element.Obstacle;
import element.Receptionner;
import element.Sociabilite;
import element.Source;
import element.Souris;
import map.Block;
import map.Grille;

public class ElementManager {
	private Grille grille;
	
	private Tours tours=new Tours(0,null);
	
	private ArrayList<Souris> souris= new ArrayList<Souris>();
	private ArrayList<Obstacle> obstacles= new ArrayList<Obstacle>();
	private ArrayList<Source> sources= new ArrayList<Source>();

	public ElementManager(Grille grille) {
		this.grille = grille;
	}
	
	/*add element*/
	public void add(Souris souris) {
		this.souris.add(souris);
	}
	public void add(Obstacle obstacle) {
		this.obstacles.add(obstacle);
	}
	public void add(Source source) {
		this.sources.add(source);
	}
	
	/*generate element*/
	public void generateSouris() {
		Block position=generatePosition(SimulationConfiguration.COLUMN_COUNT-1,SimulationConfiguration.LINE_COUNT-1);
	
		if(position!=null) {
			Souris souris = new Souris(position,generateSourisSexe(), generateSourisComportement(), SimulationConfiguration.START_SOURIS_NOURRITURE,new Memoire(new Tours(0)));
			add(souris);
		}
	}
	public void generateObstacle() {
		Block position= generatePosition(SimulationConfiguration.COLUMN_COUNT-1,SimulationConfiguration.LINE_COUNT-1);
		
		if(position!=null) {
			Obstacle obstacle= new Obstacle(position,generateStatutObstacle());
			add(obstacle);
		}
		
	}
	public void generateSource() {
		Block position= generatePosition(SimulationConfiguration.COLUMN_COUNT-1,SimulationConfiguration.LINE_COUNT-1);
		
		if(position!=null) {
			Source source = new Source(position, generateSourceContent());
			add(source);
		}
	}
	/*next round*/
	public void nextRound(Tours tours) {
		removeSourisNourritureTours();
		addSourisNourritureTours();
		newComersSouris();
		communicationSouris();
		moveAllSouris();
		this.tours=tours;	
	}
	
	/*methods about souris*/
		/*all souris move*/
		public void moveAllSouris() {
			
			for(Iterator<Souris> it=souris.iterator();it.hasNext();) {
				Souris souris=it.next();
				/* on verifie si une souris a une source memorise. Si elle en a une elle se dirige vers cette derniere
				 * sinon elle bouge aleatoirement*/
				if(souris.getMemoire().getSources().isEmpty()) {
					moveDirectionSouris(souris);
				}
				else {
					shortDistance(souris);
				}
				/*on ajoute dans son journal s'il n'y a eu aucune action*/
				if(!souris.getMemoire().getMemoireParTours().containsKey(tours.getNombreTours())) {
					souris.getMemoire().getMemoireParTours().put(tours.getNombreTours(), "Déplacement");
				}
			}
		}
	
		/*souris move*/
		public void moveDirectionSouris(Souris souris) {
			Random random=new Random();
			int randInt=(int)random.nextInt(4);
			
			switch(randInt) {
			case 0:
				moveLeftSouris(souris);
				break;
			case 1:
				moveRightSouris(souris);
				break;
			case 2:
				moveTopSouris(souris);
				break;
			case 3:
				moveBottomSouris(souris);
				break;
			default:
				break;
			}
		}
		public void moveLeftSouris(Souris souris) {
			Block position=souris.getPosition();
			
			if (position.getColonne() > 0) {
				Block newPosition = grille.getBlock(position.getLigne(), position.getColonne() - 1);
				
				if(newPosition.getStatut().equals("vide")) {
					souris.setPosition(newPosition);
				}
			}
		}
		
		public void moveRightSouris(Souris souris) {
			Block position = souris.getPosition();
	
			if (position.getColonne() < SimulationConfiguration.COLUMN_COUNT - 1) {
				Block newPosition = grille.getBlock(position.getLigne(), position.getColonne() + 1);
				
				if(newPosition.getStatut().equals("vide")) {
					souris.setPosition(newPosition);
				}
			}
		}
		public void moveTopSouris(Souris souris) {
			Block position=souris.getPosition();
			
			if (position.getLigne() > 0) {
				Block newPosition = grille.getBlock(position.getLigne() - 1, position.getColonne());
				
				if(newPosition.getStatut().equals("vide")) {
					souris.setPosition(newPosition);
				}
			}
		}
		
		public void moveBottomSouris(Souris souris) {
			Block position = souris.getPosition();
	
			if (position.getLigne() < SimulationConfiguration.LINE_COUNT - 1) {
				Block newPosition = grille.getBlock(position.getLigne() + 1, position.getColonne());
				
				if(newPosition.getStatut().equals("vide")) {
					souris.setPosition(newPosition);
				}
			}
		}
		/*near source*/
		public Source nearSource(Souris souris) {
			
			int colonne=souris.getPosition().getColonne();
			int ligne=souris.getPosition().getLigne();
			
			int diffColonne=0;
			int diffLigne=0;
			int maxColonne=SimulationConfiguration.COLUMN_COUNT;
			int maxLigne=SimulationConfiguration.LINE_COUNT;
			
			Source nearSource=null;

			for(Iterator<Source> it=souris.getMemoire().getSources().iterator();it.hasNext();) {
				Source source=it.next();
				//on analyse la source memorisee ayant la distance la plus proche de a souris
				diffColonne=Math.abs(source.getPosition().getColonne()-colonne);
				diffLigne=Math.abs(source.getPosition().getLigne()-ligne);
					
				if((diffColonne<maxColonne)||(diffLigne<maxLigne)) {
					maxColonne=diffColonne;
					maxLigne=diffLigne;
					nearSource=source;
				}
			}
			return nearSource;
		}
		public void shortDistance(Souris souris) {
			int x=Math.abs(nearSource(souris).getPosition().getLigne()-souris.getPosition().getLigne());
			int y=Math.abs(nearSource(souris).getPosition().getColonne()-souris.getPosition().getColonne());
			
			if(!isInArea(souris, nearSource(souris).getPosition())) {
				if(x<0) {
					moveLeftSouris(souris);
				}
				else if(x>0){
					moveRightSouris(souris);
				}
				else {
					if(y<0) {
						moveBottomSouris(souris);
					}
					if(y>0) {
						moveTopSouris(souris);	
					}
				}
			}
		}
		/*generate souris sexe*/
		public String generateSourisSexe() {
			int randInt=randomPercentage();
			if(randInt<=SimulationConfiguration.GENERATION_SEXE) {
				return "femele";
			}
			else {
				return "male";
			}
		}
		/*souris give birth*/
		public boolean isGiveBirthSouris(Souris souris) {
			if(souris.getNourriture()>=SimulationConfiguration.NEW_SOURIS) {
				return true;
			}
			return false;
		}
		public void newComersSouris() {
			ArrayList<Souris> enfants=new ArrayList<Souris>();
			
			for (Iterator<Souris> it=souris.iterator();it.hasNext();) {
				Souris souris=it.next();
				
				if(isGiveBirthSouris(souris)) {
					Block position=generatePosition(SimulationConfiguration.COLUMN_COUNT-1,SimulationConfiguration.LINE_COUNT-1);
					
					if(position!=null) {
						//creation enfant
						Souris newSouris=new Souris(position,generateSourisSexe(),souris.getComportement(), SimulationConfiguration.START_SOURIS_NOURRITURE,new Memoire(tours));
						
						enfants.add(newSouris);
						souris.getMemoire().getEnfants().add(newSouris);
						
						//la souris emmorise son enfant
						if(souris.getMemoire().getMemoireParTours().containsKey(tours.getNombreTours())) {
							souris.getMemoire().getMemoireParTours().remove(tours.getNombreTours());
						}
						souris.getMemoire().memoireParTours(tours.getNombreTours(),"Enfant");
					}
				}
			}
			for (Souris souris : enfants) {
				add(souris);
			}
				
		}
		/*generate souris comportement*/
		public Comportement generateSourisComportement() {
			
			return new Comportement(generateSourisCommunication(),generateSourisSociabilite());
			
		}
		public Sociabilite generateSourisSociabilite() {
			return new Sociabilite(randomPercentage());
			
		}
		public Communication generateSourisCommunication() {
			return new Communication(generateSourisDiffuser(),generateSourisReceptionner());
		}
		public Diffuser generateSourisDiffuser() {
			int randInt=randomPercentage();
			if(randInt<=SimulationConfiguration.GENERATION_COOPERATIVE) {
				return new Diffuser("cooperative");
			}
			else {
				return new Diffuser("egoiste");
			}
		}
		public Receptionner generateSourisReceptionner() {
			int randInt=randomPercentage();
			if(randInt<=SimulationConfiguration.GENERATION_RECEPTIVE) {
				return new Receptionner("receptive");
			}
			else {
				return new Receptionner("nihiliste");
			}
		}
		/*nourriture souris*/
 		public void removeSourisNourritureContent(Souris souris) {	
 			int nourriture=souris.getNourriture();
 			if(nourriture>0) {
 				souris.setNourriture(nourriture-1);
 			}
		}
		public void removeSourisNourritureTours() {
			ArrayList<Souris> sourisSuppArray=new ArrayList<Souris>();
			
			for (Iterator<Souris> it=souris.iterator();it.hasNext();) {
				Souris souris=it.next();
				
				obstaclePiege(souris);
				removeSourisNourritureContent(souris);
				
				if(souris.getNourriture()==0) {
					//memorisation du deces
					souris.getMemoire().setMortTours(tours.getNombreTours());
					souris.getMemoire().memoireParTours(tours.getNombreTours(),"Décès");
					
					souris.getPosition().setStatut("vide");
					sourisSuppArray.add(souris);
				}
			}
			for(Souris sourisSupp :sourisSuppArray) {
				this.souris.remove(sourisSupp);
			}
		}
		public void addSourisNourritureContent(Souris souris){
			int nourriture=souris.getNourriture();
			ArrayList<Source> sourceSuppArray=new ArrayList<Source>();
			
			for (Iterator<Source> it=sources.iterator();it.hasNext();) {
				Source source=it.next();
				//Si la souris a une source proche d'elle et qu'elle n'a pas le nombre maximum de nourriture, elle peut se nourrir
				if(isInArea(souris,source.getPosition())) {
					
					if(nourriture<=SimulationConfiguration.MAX_SOURIS_NOURRITURE-2) {
		 				souris.setNourriture(nourriture+2);
		 				
		 				//si elle ne connait pas cette soure elle l'a memorise
		 				if(!souris.getMemoire().getSources().contains(source)) {
		 					souris.getMemoire().getSources().add(source);				
		 				}
		 				//si action vide pour ce tour ci , elle ajoute qu'elle s'est nourrie comme action dans son journal
		 				if(!souris.getMemoire().getMemoireParTours().containsKey(tours.getNombreTours())) {
	 						souris.getMemoire().memoireParTours(tours.getNombreTours(), "Source");
						}
		 				
		 				removeSourceContent(source);
		 				
		 				if(source.getNourriture()==0) {
		 					
		 					source.getPosition().setStatut("vide");
		 					if(souris.getMemoire().getSources().contains(source)) {
		 						souris.getMemoire().getSources().remove(source);
		 					}
		 					sourceSuppArray.add(source);
						}
		 			}
				}
			}
			for(Source sourceSupp :sourceSuppArray) {
				this.sources.remove(sourceSupp);
			}
		}
		public void addSourisNourritureTours() {
			for (Iterator<Souris> it=souris.iterator();it.hasNext();) {
				Souris souris=it.next();
				
				addSourisNourritureContent(souris);
			}
		}
		/*find souris area*/
		public boolean isInArea(Souris souris,Block position) {
			int ligne=souris.getPosition().getLigne();
			int colonne=souris.getPosition().getColonne();
			
			for(int l=0;l<3;l++) {
				if(position.getLigne()==(ligne-1+l)) {
					for(int r=0;r<3;r++) {
						if(position.getColonne()==(colonne-1+r)) {
							return true;
						}
					}
				}
			}
			return false;
		}

		/*souris in same position*/
		public boolean samePosition(Souris souris1, Souris souris2) {
			if(souris1.getPosition().equals(souris2.getPosition())) {
				return true;
			}
			return false;
		}
		/*souris communication*/
		public boolean isCooperative(Souris souris) {
			int seuil=SimulationConfiguration.SEUIL_COOPERATION;
			int chanceCooperation=souris.getComportement().getSociabilite().getValeurSociabilite();
			boolean bool=false;
			
			/*La souris partage une information selon sa sociabilite et un seuil seuil. Si le seuil est de 40% de 
			 * chance de cooperer pour une souris cooperative et qu'elle a une sociabilite inferieur au seuil 
			 * elle ne partagera pas l'information malgre qu'elle soit cooperative .*/
			
			
			if(souris.getComportement().getCommunication().getDiffuser().getType().equals("cooperative")) {
				if(chanceCooperation<=seuil) {
					bool=true;
				}
			}
			if(souris.getComportement().getCommunication().getDiffuser().getType().equals("egoiste")) {
				if(chanceCooperation>seuil) {
					bool=true;
				}
			}
			return bool;
		}
		public boolean isReceptive(Souris souris) {
			int seuil=SimulationConfiguration.SEUIL_RECEPTION;
			int chanceReception=souris.getComportement().getSociabilite().getValeurSociabilite();
			boolean bool=false;
			// meme fonctionnement que pour isCooperative()
			if(souris.getComportement().getCommunication().getReceptionner().getType().equals("receptive")) {
				if(chanceReception<=seuil) {
					bool=true;
				}
			}
			if(souris.getComportement().getCommunication().getReceptionner().getType().equals("nihiliste")) {
				if(chanceReception>seuil) {
					bool=true;
				}
			}
			return bool;
		}
		public void communicationBetween2Souris(Souris souris1,Souris souris2) {
			
			if((isCooperative(souris1))&&(isReceptive(souris2))) {
				
				if(!souris1.getMemoire().getSources().isEmpty()) {
					int index=(int) (Math.random()*(souris1.getMemoire().getSources().size()));
					
					Source source=souris1.getMemoire().getSources().get((index));
					if(!souris2.getMemoire().getSources().contains(source)){
						souris2.getMemoire().getSources().add(source);
					}
 				}
				souris2.getMemoire().getSouris().add(souris1);
				
				int randInt=randomPercentage();
				if(randInt>50) {
					souris2.getMemoire().setMariage(souris1);
					
					if(!souris2.getMemoire().getMemoireParTours().containsKey(tours.getNombreTours())) {
						souris2.getMemoire().getMemoireParTours().remove(tours.getNombreTours());
					}
					souris2.getMemoire().memoireParTours(tours.getNombreTours(), "Mariage");
				}
			}
		}
		public void communicationSouris() {
			for (int index0=0;index0<souris.size();index0++) {			
				for (int index1=0;index1<souris.size();index1++) {
					if(index0!=index1&&isInArea(souris.get(index0),souris.get(index1).getPosition())){
						communicationBetween2Souris(souris.get(index0),souris.get(index1));
						
					}
				}
			}
		}
	/*methods about obstacle*/
		/*generate obstacle*/
		public String generateStatutObstacle() {
			int randInt=randomPercentage();
			if(randInt<50) {
				return "murs";
			}
			else {
				return "piege";
			}
		}
		public void obstaclePiege(Souris souris) {
			for (Iterator<Obstacle> it=obstacles.iterator();it.hasNext();) {
				Obstacle obstacle=it.next();
				
				if(isInArea(souris,obstacle.getPosition())) {
					if(!souris.getMemoire().getObstacles().contains(obstacle)) {
						souris.getMemoire().getObstacles().add(obstacle);
					}
					
					removeSourisNourritureContent(souris);
				}
			}
		}
	/*source methods*/
		/*generate source content*/
		public int generateSourceContent() {
			Random random=new Random();
			return(int)random.nextInt(SimulationConfiguration.SOURCE_CONTENT);
		}
		
		public void removeSourceContent(Source source) {
			int nourriture=source.getNourriture();
 			if(nourriture>0) {
 				source.setNourriture(nourriture-2);
 			}
		}
	/*position*/
		/*generate random not full position */
		public int randomColonne(int maxColonne) {
			return (int) (Math.random()*(maxColonne+1));
		}
		
		public int randomLigne(int maxLigne) {
			return (int) (Math.random()*(maxLigne+1));
		}
		
		public Block generatePosition(int maxLigne, int maxColonne) {	
			int colonne= randomColonne(maxColonne);
			int ligne= randomLigne(maxLigne);
		
			Block position= grille.getBlock(ligne, colonne);
			if(position.getStatut().equals("vide")) {
				position.setStatut("plein");
				return position;
			}
			else{
				while(position.getStatut().equals("plein")){
					colonne= randomColonne(maxColonne);
					ligne= randomLigne(maxLigne);
				
					position= grille.getBlock(ligne, colonne);
				}
				position.setStatut("plein");
				return position;
			}
		}
	/*getters*/
		
	public ArrayList<Souris> getSouris() {
		return souris;
	}

	public Tours getTours() {
		return tours;
	}

	public ArrayList<Obstacle> getObstacles() {
		return obstacles;
	}

	public ArrayList<Source> getSources() {
		return sources;
	}
	/*generate random percentage*/
	public int randomPercentage() {
		return (int) (Math.random()*100);
	}
}
