package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class HomeHelpGUI extends JDialog{

	private static final long serialVersionUID = 1L;
	
	private JTextArea aideT;
	private JScrollPane jspAide;
	
	public HomeHelpGUI() {
		super();
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout());
		aideT=new JTextArea(" Parmi les fonctionnalités proposées vous pouvez choisir pour la future simulation : "
				+ "\n\n- la longueur des côtés de la grille avec pour minimum 20 blocks et maximum 40 blocks."
				+ "\n\n- le nombre de tours. Un tour équivaut à 1 seconde."
				+ "\n\n- le nombre de souris."
				+ "\n\n- le nombre de sources."
				+ "\n\n- le nombre d'obstacles."
				+ "\n\n- le pourcentage de souris femelles. Le reste est comblé par des mâles."
				+ "\n\n- le pourcentage de souris coopératives. Le reste est comblé per des égoistes."
				+ "\n\n- le pourcentage de souris réceptives. Le reste est comblé per des nihilistes."
				+ "\n\n- la chance qu'une souris veuille coopérer. Si ce paramètre est égal à 0, "
				+ "quelque soit la proportion de souris coopérative dans la simulation, aucune souris ne coopéra."
				+ "\n\n- la chance qu'une souris veuille réceptionner. Si ce paramètre est égal à 0, "
				+ "quelque soit la proportion de souris coopérative dans la simulation, aucune souris ne réceptionnera."
				+ "\n\n- la capacité maximale de stockage de nourriture des souris."
				+ "\n\n- la capacité maximale de stockage de nourriture des sources."
				+ "\n\n- la capacité de départ de stockage de nourriture des souris."
				+ "\n\n- le nombre de nourriture nécessaire pour qu'une souris enfante."
				+ "\n\n\n Vocabulaire : "
				+ "\n\n- femelle/male = c'est le sexe des souris , il influence juste les mariages."
				+ "\n\n- mariage = liaison de deux souris."
				+ "\n\n- enfant = souris issue d'une souris mâle ou femelle."
				+ "\n\n- coopératives = souris qui veulent partager une information"
				+ "\n\n- égoistes = souris qui ne veulent pas partager une information"
				+ "\n\n- réceptives = souris qui veulent recevoir une information"
				+ "\n\n- coopératives = souris qui ne veulent pas recevoir une information"
				+ "\n\n- Attention une souris peut-être égoiste et avoir une chance de partager une information. "
				+ "Si il y a 0% des souris qui sont coopératives et 100% de chance de partager une information. "
				+ "Les souris seront égoistes mais parategeront tout de même l'information.");
				
		aideT.setEditable(false);
		aideT.setLineWrap(true);
		aideT.setWrapStyleWord(true);

		jspAide=new JScrollPane(aideT);
		jspAide.setPreferredSize(new Dimension(400,500));

		contentPane.add(jspAide);
		pack();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
