package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import configuration.SimulationConfiguration;
import element.Souris;

public class JournalGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	
	private final static Dimension preferredSize = new Dimension(300,400);
	
	private JLabel journalT;
	
	private ImageIcon image;
	
	private JLabel icon;
	
	private JLabel journalActivite;
	
	private Souris souris; 

	public JournalGUI(Souris souris) {
		super("Journal");
		this.souris=souris;
		init();
	}

	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		journalT=new JLabel("Tours :"+souris.getMemoire().getNaissance().getNombreTours());
		
		contentPane.add(journalT,BorderLayout.NORTH);
		
		if(souris.getSexe().equals("male")) {
			image= new ImageIcon("../SourisGLP/src/images/souris_male.png");
		}
		else {
			image= new ImageIcon("../SourisGLP/src/images/souris_femelle.png");
		}
		Image img=image.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
		image=new ImageIcon(img);
		icon= new JLabel(image);
		
		contentPane.add(icon,BorderLayout.CENTER);
		
		journalActivite=new JLabel("Naissance");
		
		contentPane.add(journalActivite,BorderLayout.SOUTH);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		setVisible(true);
		setPreferredSize(preferredSize);
		pack();
		setResizable(true);
	}

	@Override
	public void run() {
		int tours=souris.getMemoire().getNaissance().getNombreTours();
		int i=souris.getMemoire().getMortTours();
		
		while (tours<=i&&isDisplayable()&&tours<=SimulationConfiguration.STOP_TOURS) {	
			try {
				Thread.sleep(SimulationConfiguration.SIMULATION_SPEED);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			
			journalT.setText("Tours :"+tours);
			
			String activite=souris.getMemoire().getMemoireParTours().get(tours);
			journalActivite.setText(activite);
			
			if(activite.equals("Déplacement")) {
				image= new ImageIcon("../SourisGLP/src/images/deplacement.png");
			}
			else if(activite.equals("Enfant")){
				image= new ImageIcon("../SourisGLP/src/images/enfant.png");
			}
			else if(activite.equals("Source")){
				image= new ImageIcon("../SourisGLP/src/images/source.png");
			}
			else if(activite.equals("Mariage")){
				image= new ImageIcon("../SourisGLP/src/images/mariage.png");
			}
			else if(activite.equals("Décès")){
				image= new ImageIcon("../SourisGLP/src/images/deces.png");
			}
			
			Image img=image.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
			image=new ImageIcon(img);
			icon.setIcon(image);
				
			tours++;
			i=souris.getMemoire().getMortTours();
		}
	}
}

