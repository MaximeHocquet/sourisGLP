package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;

import configuration.SimulationConfiguration;
import duree.Tours;
import element.Souris;
import gui.instrument.ChartManager;
import map.Block;
import map.Grille;
import process.SimulationBuilder;
import process.ElementManager;

public class MainGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	
	/*panel buttons*/
	private JPanel buttons = new JPanel();
	
	private JButton stopperB = new JButton(" Stopper la simulation ");
	
	private JButton reprendreB = new JButton(" Reprendre la simulation ");
	
	private JButton quitterB = new JButton(" Quitter la simulation ");
	
	private JButton aideB = new JButton(" Aide ");
	
	private JPanel statsPanel = new JPanel();
	
	private JLabel journalT;
	
	private Grille grille;
	
	private final static Dimension preferredSize = new Dimension(SimulationConfiguration.WINDOW_WIDTH, SimulationConfiguration.WINDOW_HEIGHT);
		
	private ElementManager manager;
	
	private ChartManager chartManager;
	
	private ChartPanel typeCountBar;
	
	private SimulationDisplay dashboard;

	public MainGUI(String title) {
		super(title);
		init();
		buttons();
	}

	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		buttons.setLayout(new GridLayout(0, 4));
		
		buttons.add(stopperB);
		buttons.add(reprendreB);
		buttons.add(quitterB); 
		buttons.add(aideB); 
				
		contentPane.add(buttons,BorderLayout.NORTH);
		
		grille = SimulationBuilder.buildMap();
		manager = SimulationBuilder.buildInitMobile(grille);
		dashboard = new SimulationDisplay(grille, manager);

		dashboard.setPreferredSize(preferredSize);
		contentPane.add(dashboard,BorderLayout.CENTER);
		
		MouseControls mouseControls = new MouseControls();
		dashboard.addMouseListener(mouseControls);
		
		statsPanel.setLayout(new BorderLayout());
		
		journalT=new JLabel(" Tours : 0 ");
		
		statsPanel.add(journalT,BorderLayout.NORTH);
		
		chartManager = new ChartManager(manager);
		typeCountBar = new ChartPanel(chartManager.getTypeCountBar());
		
		typeCountBar.setPreferredSize(new Dimension(400,200));
		statsPanel.add(typeCountBar,BorderLayout.CENTER);
		
		
		contentPane.add(statsPanel,BorderLayout.EAST);

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setVisible(true);
		setResizable(true);
		setLocationRelativeTo(null);
		setMinimumSize(new Dimension(1000,655));
	}
	
	@Override
	public void run() {
		
		Tours tours=manager.getTours();
		
		while (tours.getNombreTours()<=SimulationConfiguration.SIMULATION_DURATION&&isDisplayable()) {
			if(SimulationConfiguration.STOP==0) {
				try {
					Thread.sleep(SimulationConfiguration.SIMULATION_SPEED);
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
				journalT.setText(" Tours : "+tours.getNombreTours());
				
				tours.setPopulation(manager.getSouris());
				tours.exterminatePopulation();
	
				manager.nextRound(tours);
				typeCountBar.setChart(chartManager.setTypeCountBar(manager));
				dashboard.repaint();
				
				SimulationConfiguration.STOP_TOURS=tours.getNombreTours();
				tours.increment();
				
			}
		}
	}
	private class MouseControls implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();

			Block sourisPosition = dashboard.getPosition(x, y);
			
			for(Souris souris : manager.getSouris()) {
				
				if(souris.getPosition()==sourisPosition) {
					JournalGUI journalGUI = new JournalGUI(souris);

					Thread gameThread = new Thread(journalGUI);
					gameThread.start();
				}
			}
		}

		@Override
		public void mouseEntered(MouseEvent arg0) {	
		}

		@Override
		public void mouseExited(MouseEvent arg0) {	
		}

		@Override
		public void mousePressed(MouseEvent arg0) {	
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {	
		}
	}
	
	public void buttons() {
		
		stopperB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				SimulationConfiguration.STOP=1;
			}
			
		});
		
		reprendreB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				SimulationConfiguration.STOP=0;
			}
			
		});
		
		quitterB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
			
		});
		
		aideB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				new MainHelpGUI();
			}
			
		});
	}
}
