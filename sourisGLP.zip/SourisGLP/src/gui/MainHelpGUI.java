package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MainHelpGUI extends JDialog{

	private static final long serialVersionUID = 1L;
	
	private JLabel grilleT = new JLabel(" Grille : ") ;
	
	private JLabel journalT = new JLabel(" Journal : ") ;
	
	private JPanel iconsGrille = new JPanel();
	
	private JPanel iconsJournal = new JPanel();
	
	private JScrollPane jsp;
	
	private JPanel jspPanel = new JPanel();
	
	//icons grille
	private JLabel sourisMT = new JLabel(" Souris mâle : ");
	private ImageIcon sourisMIcon = new ImageIcon("../SourisGLP/src/images/souris_male.png");;
	private JLabel sourisMImage;
	
	private JLabel sourisFT = new JLabel(" Souris femele : ");
	private ImageIcon sourisFIcon = new ImageIcon("../SourisGLP/src/images/souris_femelle.png");;
	private JLabel sourisFImage = new JLabel(sourisFIcon);
	
	private JLabel obstacleT = new JLabel(" Obstacle : ");
	private ImageIcon obstacleIcon = new ImageIcon("../SourisGLP/src/images/obstacle.png");;
	private JLabel obstacleFImage = new JLabel(obstacleIcon);
	
	private JLabel sourceT = new JLabel(" Source : ");
	private ImageIcon sourceFIcon = new ImageIcon("../SourisGLP/src/images/source.png");;
	private JLabel sourceFImage = new JLabel(sourceFIcon);
	
	private JLabel grassT = new JLabel(" Herbe : ");
	private ImageIcon grassIcon = new ImageIcon("../SourisGLP/src/images/grass.png");;
	private JLabel grassImage = new JLabel(grassIcon);
			
	//icons journal
	private JLabel deplacementT = new JLabel(" Deplacement d'une souris : ");
	private ImageIcon deplacementIcon = new ImageIcon("../SourisGLP/src/images/deplacement.png");;
	private JLabel deplacementImage = new JLabel(deplacementIcon);
	
	private JLabel decesT = new JLabel(" Deces d'une souris : ");
	private ImageIcon decesIcon = new ImageIcon("../SourisGLP/src/images/deces.png");;
	private JLabel decesImage = new JLabel(decesIcon);
	
	private JLabel enfantT = new JLabel(" Enfant d'une souris : ");
	private ImageIcon enfantIcon = new ImageIcon("../SourisGLP/src/images/enfant.png");;
	private JLabel enfantImage = new JLabel(enfantIcon);
	
	private JLabel mariageT = new JLabel(" Mariage de deux souris : ");	
	private ImageIcon mariageIcon = new ImageIcon("../SourisGLP/src/images/mariage.png");;
	private JLabel mariageImage = new JLabel(mariageIcon);
	
	public MainHelpGUI() {
		super();
		init();
	}
	
	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout());
		
		jspPanel.setLayout(new GridLayout(4, 0));
		iconsGrille.setLayout(new GridLayout(4, 2));
		iconsJournal.setLayout(new GridLayout(5, 2));
		
		Image img;
		
		img = sourisMIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		sourisMIcon =new ImageIcon(img);
		sourisMImage = new JLabel(sourisMIcon);
		
		img = sourisFIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		sourisFIcon =new ImageIcon(img);
		sourisFImage = new JLabel(sourisFIcon);
		
		img = obstacleIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		obstacleIcon =new ImageIcon(img);
		obstacleFImage = new JLabel(obstacleIcon);
		
		img = sourceFIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		sourceFIcon =new ImageIcon(img);
		sourceFImage = new JLabel(sourceFIcon);
		
		img = grassIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		grassIcon =new ImageIcon(img);
		grassImage = new JLabel(grassIcon);

		img = deplacementIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		deplacementIcon =new ImageIcon(img);
		deplacementImage = new JLabel(deplacementIcon);
		
		img = decesIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		decesIcon =new ImageIcon(img);
		decesImage = new JLabel(decesIcon);
		
		img = enfantIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		enfantIcon =new ImageIcon(img);
		enfantImage = new JLabel(enfantIcon);
		
		img = mariageIcon.getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		mariageIcon =new ImageIcon(img);
		mariageImage = new JLabel(mariageIcon);
		
		iconsGrille.add(sourisMT);
		iconsGrille.add(sourisMImage);
		
		iconsGrille.add(sourisFT);
		iconsGrille.add(sourisFImage);
		
		iconsGrille.add(obstacleT);
		iconsGrille.add(obstacleFImage);
		
		iconsGrille.add(sourceT);
		iconsGrille.add(sourceFImage);
		
		jspPanel.add(grilleT);
		jspPanel.add(iconsGrille);
		
		iconsJournal.add(grassT);
		iconsJournal.add(grassImage);
		
		iconsJournal.add(deplacementT);
		iconsJournal.add(deplacementImage);
		
		iconsJournal.add(enfantT);
		iconsJournal.add(enfantImage);
		
		iconsJournal.add(decesT);
		iconsJournal.add(decesImage);
		
		iconsJournal.add(mariageT);
		iconsJournal.add(mariageImage);

		jspPanel.add(journalT);
		jspPanel.add(iconsJournal);
	
		jsp = new JScrollPane(jspPanel);
		jsp.setPreferredSize(new Dimension(400,500));
		
		contentPane.add(jsp);
		pack();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
