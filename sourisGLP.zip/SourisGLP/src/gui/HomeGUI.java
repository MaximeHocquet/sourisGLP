package gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import configuration.SimulationConfiguration;

public class HomeGUI extends JFrame{

	private static final long serialVersionUID = 1L;
	
	/*panel presentation*/
	private JPanel presentation = new JPanel();
	
	private ImageIcon presIcon = new ImageIcon("../SourisGLP/src/images/souris_male.png");;
	
	private JLabel presImage = new JLabel(presIcon);
	
	private JLabel presT = new JLabel(" Welcome at MOUSIMULATION ");
	
	/*panel caracteristiques*/
	private JPanel caracteristiques = new JPanel();
	
	private JLabel caraT = new JLabel(" Entrer les caractéristiques de la simulation : ");
	
	private JLabel caraTBlocks = new JLabel(" Longueur des côtés (min 20 , max 40) : ");
	private JTextField caraTFBlocks = new JTextField();
	
	private JLabel caraTTours = new JLabel(" Nombre de tours : ");
	private JTextField caraTFTours = new JTextField();
	
	private JLabel caraTSouris = new JLabel(" Nombre de souris : ");
	private JTextField caraTFSouris = new JTextField();
	
	private JLabel caraTSources = new JLabel(" Nombre de sources : ");
	private JTextField caraTFSources = new JTextField();
	
	private JLabel caraTObstacles = new JLabel(" Nombre d'obstacles : ");
	private JTextField caraTFObstacles = new JTextField();
	
	private JLabel sourisTGenSexe = new JLabel(" Pourcentage de souris femelles : ");
	private JTextField sourisTFGenSexe = new JTextField();
	
	private JLabel sourisTGenCooperative = new JLabel(" Pourcentage de souris coopératives : ");
	private JTextField sourisTFGenCooperative = new JTextField();
	
	private JLabel sourisTGenReceptive = new JLabel(" Pourcentage de souris réceptives : ");
	private JTextField sourisTFGenReceptive = new JTextField();
	
	private JLabel sourisTseuilCooperative = new JLabel(" Chance de coopérer : ");
	private JTextField sourisTFseuilCooperative = new JTextField();
	
	private JLabel sourisTseuilReceptive = new JLabel(" Chance de réceptionner : ");
	private JTextField sourisTFseuilReceptive = new JTextField();
	
	private JLabel sourisTNourritureMax = new JLabel(" Capacité de stockage de nourriture maximale des souris : ");
	private JTextField sourisTFNourritureMax = new JTextField();
	
	private JLabel sourcesTNourritureMax = new JLabel(" Capacité de stockage de nourriture maximale des sources : ");
	private JTextField sourcesTFNourritureMax = new JTextField();
	
	private JLabel sourisTNourritureStart = new JLabel(" Capacité de stockage de nourriture départ des souris : ");
	private JTextField sourisTFNourritureStart = new JTextField();
	
	private JLabel sourisTNourritureNew = new JLabel(" Nourriture nécessaire pour enfanter : ");
	private JTextField sourisTFNourritureNew = new JTextField();
	
	/*panel buttons*/
	private JPanel buttons = new JPanel();
	
	private JButton aideB = new JButton(" Aide ");
	
	private JButton runB = new JButton(" Lancer la simulation ");
	
	public HomeGUI(String title) {
		super(title);
		init();
		buttons();
	}
	
	private void init() {
		
		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		presentation.setLayout(new GridLayout(2, 2));
		
		presentation.add(presImage);
		presentation.add(presT);
		presentation.add(caraT);
		
		contentPane.add(presentation,BorderLayout.NORTH);
		
		caracteristiques.setLayout(new GridLayout(14, 2));
		
		caracteristiques.add(caraTBlocks);
		caracteristiques.add(caraTFBlocks);
		
		caracteristiques.add(caraTTours);
		caracteristiques.add(caraTFTours);
		
		caracteristiques.add(caraTSouris);
		caracteristiques.add(caraTFSouris);
		
		caracteristiques.add(caraTSources);
		caracteristiques.add(caraTFSources);
		
		caracteristiques.add(caraTObstacles);
		caracteristiques.add(caraTFObstacles);
		
		caracteristiques.add(sourisTGenSexe);
		caracteristiques.add(sourisTFGenSexe);
		
		caracteristiques.add(sourisTGenCooperative);
		caracteristiques.add(sourisTFGenCooperative);
		
		caracteristiques.add(sourisTGenReceptive);
		caracteristiques.add(sourisTFGenReceptive);
		
		caracteristiques.add(sourisTseuilCooperative);
		caracteristiques.add(sourisTFseuilCooperative);
		
		caracteristiques.add(sourisTseuilReceptive);
		caracteristiques.add(sourisTFseuilReceptive);
		
		caracteristiques.add(sourisTNourritureMax);
		caracteristiques.add(sourisTFNourritureMax);
		
		caracteristiques.add(sourcesTNourritureMax);
		caracteristiques.add(sourcesTFNourritureMax);
		
		caracteristiques.add(sourisTNourritureStart);
		caracteristiques.add(sourisTFNourritureStart);
		
		caracteristiques.add(sourisTNourritureNew);
		caracteristiques.add(sourisTFNourritureNew);
		
		contentPane.add(caracteristiques,BorderLayout.CENTER);
		
		buttons.setLayout(new GridLayout(0, 2));
		
		buttons.add(aideB);
		buttons.add(runB);
		
		contentPane.add(buttons,BorderLayout.SOUTH);
				
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setLocationRelativeTo(null);
		setResizable(true);
	}
	public void buttons() {
		runB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				if(!caraTFBlocks.getText().isEmpty()) {
					int block=Integer.parseInt(caraTFBlocks.getText());
					
					if(block<=40&&block>=20) {
						SimulationConfiguration.LINE_COUNT=block;
						SimulationConfiguration.COLUMN_COUNT=block;
					}
				}
				if(!caraTFTours.getText().isEmpty()) {
					SimulationConfiguration.SIMULATION_DURATION=Integer.parseInt(caraTFTours.getText());
				}
				if(!caraTFSouris.getText().isEmpty()) {
					SimulationConfiguration.NUMBER_SOURIS=Integer.parseInt(caraTFSouris.getText());
				}
				if(!caraTFSources.getText().isEmpty()) {
					SimulationConfiguration.NUMBER_SOURCE=Integer.parseInt(caraTFSources.getText());
				}
				if(!caraTFObstacles.getText().isEmpty()) {
					SimulationConfiguration.NUMBER_OBSTACLE=Integer.parseInt(caraTFObstacles.getText());
				}
				if(!sourisTFGenCooperative.getText().isEmpty()) {
					SimulationConfiguration.GENERATION_COOPERATIVE=Integer.parseInt(sourisTFGenCooperative.getText());
				}
				if(!sourisTFGenReceptive.getText().isEmpty()) {
					SimulationConfiguration.GENERATION_RECEPTIVE=Integer.parseInt(sourisTFGenReceptive.getText());
				}
				if(!sourisTFseuilCooperative.getText().isEmpty()) {
					SimulationConfiguration.SEUIL_COOPERATION=Integer.parseInt(sourisTFseuilCooperative.getText());
				}
				if(!sourisTFseuilReceptive.getText().isEmpty()) {
					SimulationConfiguration.SEUIL_RECEPTION=Integer.parseInt(sourisTFseuilReceptive.getText());
				}
				if(!sourisTFGenSexe.getText().isEmpty()) {
					SimulationConfiguration.GENERATION_SEXE=Integer.parseInt(sourisTFGenSexe.getText());
				}
				if(!sourisTFNourritureMax.getText().isEmpty()) {
					SimulationConfiguration.MAX_SOURIS_NOURRITURE=Integer.parseInt(sourisTFNourritureMax.getText());
				}
				if(!sourcesTFNourritureMax.getText().isEmpty()) {
					SimulationConfiguration.SOURCE_CONTENT=Integer.parseInt(sourcesTFNourritureMax.getText());
				}
				if(!sourisTFNourritureStart.getText().isEmpty()) {
					SimulationConfiguration.START_SOURIS_NOURRITURE=Integer.parseInt(sourisTFNourritureStart.getText());
				}
				if(!sourisTFNourritureNew.getText().isEmpty()) {
					SimulationConfiguration.NEW_SOURIS=Integer.parseInt(sourisTFNourritureNew.getText());
				}
				
				MainGUI gameMainGUI = new MainGUI("Mousimulation");

				Thread gameThread = new Thread(gameMainGUI);
				gameThread.start();
			}
		});
		
		aideB.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				new HomeHelpGUI();
			}
			
		});
	}
}