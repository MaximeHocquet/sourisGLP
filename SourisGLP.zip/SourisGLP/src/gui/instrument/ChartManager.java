package gui.instrument;

import java.util.Iterator;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import element.Source;
import element.Souris;
import process.ElementManager;

public class ChartManager {
	private DefaultCategoryDataset dataset;
	
	private int sources=0;
	private int souris=0;
	private int males=0;
	private int femeles=0;
	private int egoistes=0;
	private int cooperatives=0;
	private int receptives=0;
	private int nihilistes=0;
	private int mariees=0;

	public ChartManager(ElementManager manager) {
		
		for (Iterator<Souris> it=manager.getSouris().iterator();it.hasNext();) {
			Souris souris=it.next();
			this.souris++;
			if(souris.getSexe()=="male") {
				males++;
			}
			if(souris.getSexe()=="femele"){
				femeles++;
			}
			if(souris.getComportement().getCommunication().getDiffuser().getType()=="egoiste") {
				egoistes++;
			}
			if(souris.getComportement().getCommunication().getDiffuser().getType()=="cooperative") {
				cooperatives++;
			}
			if(souris.getComportement().getCommunication().getReceptionner().getType()=="receptive") {
				receptives++;
			}
			if(souris.getComportement().getCommunication().getReceptionner().getType()=="nihiliste") {
				nihilistes++;
			}
			if(souris.getMemoire().getMariage()!=null) {
				mariees++;
			}
		}
		for (Source source : manager.getSources()) {
			this.sources++;
		}
	}

	public JFreeChart getTypeCountBar() {
		
		dataset = new DefaultCategoryDataset();

		dataset.setValue(sources, "sources", "Sources");
		dataset.setValue(souris, "souris", "Souris");
		dataset.setValue(males, "sexe", "Male");
		dataset.setValue(femeles, "sexe", "Femele");
		dataset.setValue(egoistes, "diffuser", "Egoiste");
		dataset.setValue(cooperatives, "diffuser", "Cooperative");
		dataset.setValue(receptives, "receptionner", "Receptive");
		dataset.setValue(nihilistes, "receptionner", "Nihiliste");
		dataset.setValue(mariees, "mariage", "Mariee");
		
		return ChartFactory.createBarChart("", "Node type", "Count", dataset, PlotOrientation.VERTICAL, true, true, false);
	}
	public JFreeChart setTypeCountBar(ElementManager manager) {
		sources=0;
		souris=0;
		males=0;
		femeles=0;
		egoistes=0;
		cooperatives=0;
		receptives=0;
		nihilistes=0;
		mariees=0;
		
		for (Iterator<Souris> it=manager.getSouris().iterator();it.hasNext();) {
			Souris souris=it.next();
			this.souris++;
			if(souris.getSexe()=="male") {
				males++;
			}
			if(souris.getSexe()=="femele"){
				femeles++;
			}
			if(souris.getComportement().getCommunication().getDiffuser().getType()=="egoiste") {
				egoistes++;
			}
			if(souris.getComportement().getCommunication().getDiffuser().getType()=="cooperative") {
				cooperatives++;
			}
			if(souris.getComportement().getCommunication().getReceptionner().getType()=="receptive") {
				receptives++;
			}
			if(souris.getComportement().getCommunication().getReceptionner().getType()=="nihiliste") {
				nihilistes++;
			}
			if(souris.getMemoire().getMariage()!=null) {
				mariees++;
			}
		}
		for (Source source : manager.getSources()) {
			this.sources++;
		}

		dataset.setValue(sources, "sources", "Sources");
		dataset.setValue(souris, "souris", "Souris");
		dataset.setValue(males, "sexe", "Male");
		dataset.setValue(femeles, "sexe", "Femele");
		dataset.setValue(egoistes, "diffuser", "Egoiste");
		dataset.setValue(cooperatives, "diffuser", "Cooperative");
		dataset.setValue(receptives, "receptionner", "Receptive");
		dataset.setValue(nihilistes, "receptionner", "Nihiliste");
		dataset.setValue(mariees, "mariage", "Mariee");
		
		return ChartFactory.createBarChart("", "Node type", "Count", dataset, PlotOrientation.VERTICAL, true, true, false);
	}

}
