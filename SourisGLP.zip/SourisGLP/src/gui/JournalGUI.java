package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import configuration.SimulationConfiguration;
import duree.Tours;
import element.Souris;

public class JournalGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	
	private final static Dimension preferredSize = new Dimension(300,300);
	
	private JLabel journalT;
	
	private ImageIcon image;
	
	private JLabel icon;
	
	private Souris souris; 

	public JournalGUI(Souris souris) {
		super("Journal");
		this.souris=souris;
		init();
	}

	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(2, 1));
		
		journalT=new JLabel("Tours :"+souris.getMemoire().getNaissance().getNombreTours());
		contentPane.add(journalT);
		
		
		if(souris.getSexe().equals("male")) {
			image= new ImageIcon("../SourisGLP/src/images/souris_male.png");
		}
		else {
			image= new ImageIcon("../SourisGLP/src/images/souris_femelle.png");
		}
		icon= new JLabel(image);
		icon.setPreferredSize(preferredSize);
		
		contentPane.add(icon);
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		pack();
		setVisible(true);
		setPreferredSize(preferredSize);
		setResizable(false);
	}

	@Override
	public void run() {
		Tours tours=new Tours(souris.getMemoire().getNaissance().getNombreTours());
		
		while (tours.getNombreTours()<=SimulationConfiguration.SIMULATION_DURATION&&tours.getNombreTours()<=souris.getMemoire().getMortTours().getNombreTours()) {	
			try {
				Thread.sleep(SimulationConfiguration.SIMULATION_SPEED);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			
			journalT.setText("Tours :"+tours.getNombreTours());
			souris.getMemoire().getMemoireParTours().get(tours);
			//icon.setIcon(icon);
	
			tours.increment();
		}
	}
}

