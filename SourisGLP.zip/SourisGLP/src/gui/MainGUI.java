package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;

import configuration.SimulationConfiguration;
import duree.Tours;
import element.Souris;
import gui.instrument.ChartManager;
import map.Block;
import map.Grille;
import process.SimulationBuilder;
import process.ElementManager;

public class MainGUI extends JFrame implements Runnable {

	private static final long serialVersionUID = 1L;
	
	private JPanel statsPanel = new JPanel();
	
	private Grille grille;
	
	private final static Dimension preferredSize = new Dimension(SimulationConfiguration.WINDOW_WIDTH, SimulationConfiguration.WINDOW_HEIGHT);
		
	private ElementManager manager;
	
	private ChartManager chartManager;
	
	private ChartPanel typeCountBar;
	
	private SimulationDisplay dashboard;

	public MainGUI(String title) {
		super(title);
		init();
	}

	private void init() {
		Container contentPane = getContentPane();
		contentPane.setLayout(new GridLayout(1, 2));
		
		grille = SimulationBuilder.buildMap();
		manager = SimulationBuilder.buildInitMobile(grille);
		dashboard = new SimulationDisplay(grille, manager);

		dashboard.setPreferredSize(preferredSize);
		contentPane.add(dashboard);
		
		MouseControls mouseControls = new MouseControls();
		dashboard.addMouseListener(mouseControls);
		
		statsPanel.setLayout(new GridLayout(1, 3));
		
		chartManager = new ChartManager(manager);
		typeCountBar = new ChartPanel(chartManager.getTypeCountBar());

		statsPanel.add(typeCountBar);

		
		contentPane.add(statsPanel);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		setPreferredSize(preferredSize);
		setResizable(false);
	}

	@Override
	public void run() {
		
		Tours tours=new Tours(1,null);
		
		while (tours.getNombreTours()<=SimulationConfiguration.SIMULATION_DURATION) {
			
			try {
				Thread.sleep(SimulationConfiguration.SIMULATION_SPEED);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			
			tours.setPopulation(manager.getSouris());
			tours.exterminatePopulation();

			manager.nextRound(tours);
			typeCountBar.setChart(chartManager.setTypeCountBar(manager));
			dashboard.repaint();
				
			tours.increment();

		}
	}
	private class MouseControls implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {
			int x = e.getX();
			int y = e.getY();

			Block sourisPosition = dashboard.getPosition(x, y);
			
			for(Souris souris : manager.getSouris()) {
				if(souris.getPosition()==sourisPosition) {
					
					JournalGUI journalGUI = new JournalGUI(souris);

					Thread gameThread = new Thread(journalGUI);
					gameThread.start();
				}
			}
		}

		@Override
		public void mousePressed(MouseEvent e) {

		}

		@Override
		public void mouseReleased(MouseEvent e) {

		}

		@Override
		public void mouseEntered(MouseEvent e) {

		}

		@Override
		public void mouseExited(MouseEvent e) {

		}
	}
}
