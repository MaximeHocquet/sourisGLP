package element;

public class Humeur {
	private SourisNourriture nourriture;

	public Humeur(SourisNourriture nourriture) {
		this.nourriture = nourriture;
	}
}
