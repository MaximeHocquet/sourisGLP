package element;

import java.util.ArrayList;

public class Memoire {
	private ArrayList<Informations> informations;
	public Memoire(ArrayList<Informations> informations) {
		this.informations=informations;
	}
}
